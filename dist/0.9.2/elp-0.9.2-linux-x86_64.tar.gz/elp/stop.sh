#!/bin/bash 

pkill -9 elp-front

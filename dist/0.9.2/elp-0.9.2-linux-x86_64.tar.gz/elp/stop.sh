#!/bin/bash 

pkill -9 els-front

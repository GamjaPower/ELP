#!/bin/bash 

nohup ./els-front & 


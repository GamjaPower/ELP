#!/bin/bash 

nohup ./elp-front & 


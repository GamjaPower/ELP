#!/bin/bash 

nohup ./elp-alert & 

